import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='my-skill'>
        <div className='section-title'>
          <span className='my-skills'>My Skills</span>
          <div className='content'>
            <span className='my-expertise'>My Expertise</span>
          </div>
        </div>
        <div className='row'>
          <div className='content-1'>
            <div className='section-title-2'>
              <div className='webflow-development'>
                <div className='feather-pen' />
              </div>
              <div className='content-3'>
                <span className='web-development'>Web Development</span>
                <span className='web-development-transforming'>
                  Web Development: Transforming concepts into dynamic and
                  responsive digital experiences through coding and innovative
                  solutions.
                </span>
              </div>
            </div>
          </div>
          <div className='content-4'>
            <div className='section-title-5'>
              <div className='strategy-direction'>
                <div className='feather-pen-6' />
              </div>
              <div className='content-7'>
                <span className='ui-ux-design'>UI & UX Design</span>
                <span className='ui-ux-design-seamlessly'>
                  UI/UX Design: Seamlessly blending aesthetics and functionality
                  for an intuitive and delightful user experience.
                </span>
              </div>
            </div>
          </div>
          <div className='content-8'>
            <div className='section-title-9'>
              <div className='branding-logo'>
                <div className='product-chain' />
              </div>
              <div className='content-a'>
                <span className='graphic-design'>graphic Design</span>
                <span className='graphic-design-communicating'>
                  Graphic Design: Communicating ideas through visually
                  compelling and impactful creative expressions.
                </span>
              </div>
            </div>
          </div>
          <div className='content-b'>
            <div className='section-title-c'>
              <div className='ui-ux-design-d'>
                <div className='tag' />
              </div>
              <div className='content-e'>
                <span className='branding-logo-f'>Branding & Logo</span>
                <span className='branding-logo-crafting'>
                  Branding & Logo: Crafting distinctive visual identities that
                  resonate with authenticity and brand essence.
                </span>
              </div>
            </div>
          </div>
        </div>
        <span className='my-skills-10'>My Skills</span>
        <div className='flex-row-d'>
          <span className='figma'>Figma</span>
          <span className='adobe-photoshop'>Adobe Photoshop</span>
        </div>
        <div className='flex-row-fc'>
          <div className='ellipse' />
          <div className='ellipse-11' />
          <div className='rectangle' />
          <div className='rectangle-12' />
          <div className='rectangle-13' />
          <div className='rectangle-14' />
        </div>
        <div className='flex-row-d-15'>
          <span className='adobe-illustrator'>Adobe Illustrator</span>
          <span className='adobe-xd'>Adobe XD</span>
        </div>
        <div className='flex-row-b'>
          <div className='ellipse-16' />
          <div className='ellipse-17' />
          <div className='rectangle-18' />
          <div className='rectangle-19' />
          <div className='rectangle-1a' />
          <div className='rectangle-1b' />
        </div>
        <div className='flex-row-af'>
          <span className='html-css'>HTML & CSS</span>
          <span className='javascript'>Javascript </span>
        </div>
        <div className='flex-row-defb'>
          <div className='ellipse-1c' />
          <div className='ellipse-1d' />
          <div className='rectangle-1e' />
          <div className='rectangle-1f' />
          <div className='rectangle-20' />
          <div className='rectangle-21' />
        </div>
        <div className='flex-row'>
          <span className='react-js'>React JS</span>
          <span className='balsamiq'>Balsamiq</span>
        </div>
        <div className='flex-row-e'>
          <div className='ellipse-22' />
          <div className='ellipse-23' />
          <div className='rectangle-24' />
          <div className='rectangle-25' />
          <div className='rectangle-26' />
          <div className='rectangle-27' />
        </div>
        <div className='flex-row-28'>
          <span className='wordpress'>Wordpress</span>
          <span className='git-github'>Git & Github</span>
        </div>
        <div className='flex-row-dc'>
          <div className='ellipse-29' />
          <div className='ellipse-2a' />
          <div className='rectangle-2b' />
          <div className='rectangle-2c' />
          <div className='rectangle-2d' />
          <div className='rectangle-2e' />
        </div>
      </div>
      <div className='flex-row-bea'>
        <div className='digital-pass-x' />
        <span className='about'>About</span>
        <span className='about-me'>About Me</span>
        <div className='i-am'>
          <span className='hariharan-v'>I am </span>
          <span className='a-seasoned-graphic-ui-ux-designer-based-in-coimbatore-with-a-year-of-experience-as-an-ap-analyst-at-tcs-in-chennai-i-hold-a-degree-from-dr-sns-rajalakshmi-college-of-arts-and-science-and-bring-a-comprehensive-skill-set-including-html-css-javascript-bootstrap-reactjs-and-mysql-proficient-in-adobe-photoshop-illustrator-figma-and-github-i-have-successfully-completed-three-freelance-projects-showcasing-my-expertise-in-ui-ux-design-and-web-development-beyond-my-technical-skills-my-soft-skills-such-as-honesty-effective-communication-leadership-and-design-thinking-contribute-to-my-success-in-collaborative-projects-a-certified-ui-ux-designer-and-front-end-developer-i-am-passionate-about-photography-and-have-received-recognition-for-my-work-in-short-films-i-am-eager-to-bring-my-diverse-skills-and-creative-mindset-to-contribute-to-innovative-design-projects'>
            Hariharan V
          </span>
          <span className='i-am-2f'>
            , a seasoned Graphic UI/UX Designer based in Coimbatore with a year
            of experience as an AP Analyst at TCS in Chennai. I hold a degree
            from Dr. SNS Rajalakshmi College of Arts and Science and bring a
            comprehensive skill set, including HTML, CSS, JavaScript, Bootstrap,
            ReactJS, and MySQL. Proficient in Adobe Photoshop, Illustrator,
            Figma, and GitHub, I have successfully completed three freelance
            projects, showcasing my expertise in UI/UX design and web
            development. Beyond my technical skills, my soft skills such as
            honesty, effective communication, leadership, and design thinking
            contribute to my success in collaborative projects. A certified
            UI/UX designer and front-end developer, I am passionate about
            photography and have received recognition for my work in short
            films. I am eager to bring my diverse skills and creative mindset to
            contribute to innovative design projects.
          </span>
        </div>
      </div>
      <div className='flex-row-30'>
        <div className='blog'>
          <div className='section-header'>
            <div className='section-title-31'>
              <span className='recent-projects'>Recent Projects</span>
              <div className='content-32'>
                <span className='my-portfolio'>My Portfolio</span>
              </div>
            </div>
            <button className='social-button'>
              <div className='bi-behance' />
              <span className='text'>Visit My Behance</span>
            </button>
          </div>
          <div className='group'>
            <div className='card'>
              <div className='content-33'>
                <div className='content-34'>
                  <div className='title'>
                    <span className='hash-cars-application'>
                      Hash Cars Application
                    </span>
                    <span className='hash-cars-figma-ui-ux'>
                      Hash Cars: Figma UI/UX - Sleek design, user-friendly
                      navigation, and detailed car listings for a seamless
                      experience.
                    </span>
                  </div>
                </div>
                <div className='avatar'>
                  <div className='content-35'>
                    <span className='view-in-behance'>View In Behance</span>
                    <div className='vector' />
                  </div>
                </div>
              </div>
              <div className='rectangle-36' />
              <div className='desktop' />
              <div className='desktop-37' />
            </div>
            <div className='card-38'>
              <div className='macbook' />
              <div className='content-39'>
                <div className='content-3a'>
                  <div className='title-3b'>
                    <span className='restaurant-dashboard'>
                      Restaurant Dashboard
                    </span>
                    <span className='midine-restaurant-dashboard-in-figma'>
                      MiDine Restaurant Dashboard in Figma: Intuitive UI/UX for
                      seamless restaurant management and enhanced dining
                      experiences.
                    </span>
                  </div>
                </div>
                <div className='avatar-3c'>
                  <div className='content-3d'>
                    <span className='view-in-behance-3e'>View In Behance</span>
                    <div className='vector-3f' />
                  </div>
                </div>
              </div>
            </div>
            <div className='card-40'>
              <div className='content-41'>
                <div className='content-42'>
                  <div className='title-43'>
                    <span className='rental-car-website'>
                      Rental car website
                    </span>
                    <span className='rental-car-website-in-photoshop'>
                      Rental Car Website in Photoshop: Streamlined UI/UX for
                      effortless car browsing and reservations.
                    </span>
                  </div>
                </div>
                <div className='avatar-44'>
                  <button className='button'>
                    <span className='view-in-behance-45'>View In Behance</span>
                    <div className='vector-46' />
                  </button>
                </div>
              </div>
              <div className='rectangle-47' />
              <div className='ipad-mini' />
            </div>
          </div>
          <div className='group-48'>
            <div className='card-49'>
              <div className='rectangle-4a' />
              <div className='flex-row-e-4b'>
                <div className='macbook-air' />
                <div className='content-4c'>
                  <div className='content-4d'>
                    <div className='title-4e'>
                      <span className='food-website'>Food Website</span>
                      <span className='foodsdo-website-figma'>
                        FoodsDo Website in Figma: A sleek UI/UX design enhancing
                        user experience for seamless food exploration and
                        ordering.
                      </span>
                    </div>
                  </div>
                  <div className='avatar-4f'>
                    <div className='content-50'>
                      <span className='view-in-behance-51'>
                        View In Behance
                      </span>
                      <div className='vector-52' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='card-53'>
              <div className='content-54'>
                <div className='content-55'>
                  <div className='title-56'>
                    <span className='mob-application'>MOB Application</span>
                    <span className='mob-application-figma'>
                      MOB Application in Figma: An intuitive UI/UX design for
                      streamlined mobile interactions, ensuring a seamless and
                      user-friendly experience.
                    </span>
                  </div>
                </div>
                <div className='avatar-57'>
                  <div className='content-58'>
                    <span className='view-in-behance-59'>View In Behance</span>
                    <div className='vector-5a' />
                  </div>
                </div>
              </div>
            </div>
            <div className='card-5b'>
              <div className='flex-row-b-5c'>
                <div className='apple-watch-ultra' />
                <div className='rectangle-5d' />
              </div>
              <div className='content-5e'>
                <div className='content-5f'>
                  <div className='title-60'>
                    <span className='smart-watch-ui'>Smart watch UI</span>
                    <span className='smartwatch-ui-figma'>
                      Smartwatch UI in Figma: A minimalist and intuitive design
                      for a seamless user experience, enhancing the interaction
                      with smartwatch functionalities.
                    </span>
                  </div>
                </div>
                <div className='avatar-61'>
                  <div className='content-62'>
                    <span className='view-in-behance-63'>View In Behance</span>
                    <div className='vector-64' />
                  </div>
                </div>
              </div>
            </div>
            <div className='iphone-pro' />
          </div>
          <div className='flex-row-b-65'>
            <div className='card-66'>
              <div className='wall-sign' />
            </div>
            <div className='card-67'>
              <div className='rectangle-68'>
                <div className='outdoor-mockup' />
              </div>
              <div className='title-69'>
                <span className='new-year-poster'>New Year Poster</span>
                <span className='new-year-poster-photoshop'>
                  New Year Poster in Photoshop: A vibrant and celebratory UI/UX
                  design, capturing the spirit of the new year in a visually
                  appealing composition.
                </span>
              </div>
              <span className='view-in-behance-6a'>View In Behance</span>
              <div className='vector-6b' />
            </div>
            <div className='card-6c'>
              <div className='rectangle-6d'>
                <div className='folder-mockup' />
              </div>
              <div className='title-6e'>
                <span className='packaging-design'>Packaging Design</span>
                <span className='packaging-design-illustrator'>
                  Packaging Design in Illustrator: seamlessly merging creativity
                  with practicality for effective product presentation.
                </span>
              </div>
              <span className='view-in-behance-6f'>View In Behance</span>
              <div className='vector-70' />
            </div>
            <div className='content-71'>
              <div className='content-72'>
                <div className='title-73'>
                  <span className='milkshake-poster'>Milkshake Poster</span>
                  <span className='milkshake-poster-photoshop'>
                    Milkshake Poster in Photoshop: A visually enticing UI/UX
                    design, creating an appetizing appeal for milkshake
                    enthusiasts.
                  </span>
                </div>
              </div>
              <div className='avatar-74'>
                <div className='content-75'>
                  <span className='view-in-behance-76'>View In Behance</span>
                  <div className='vector-77' />
                </div>
              </div>
            </div>
          </div>
          <div className='flex-row-c'>
            <div className='card-78'>
              <div className='rectangle-79'>
                <div className='torn-posters' />
              </div>
            </div>
            <div className='card-7a'>
              <div className='business-cards' />
              <div className='title-7b'>
                <span className='package-design'>Package Design</span>
                <span className='box-package-design-illustrator'>
                  Box Package Design in Illustrator: A visually appealing and
                  functional packaging design seamlessly created to enhance
                  product presentation.
                </span>
              </div>
              <span className='view-in-behance-7c'>View In Behance</span>
              <div className='vector-7d' />
            </div>
            <div className='card-7e'>
              <div className='rectangle-7f'>
                <div className='pizza-box-mockup-v-front-view' />
              </div>
              <div className='title-80'>
                <span className='clean-teeth-poster'>Clean Teeth Poster</span>
                <span className='clean-teeth-poster-illustrator'>
                  Clean Teeth Poster in Illustrator: A vibrant and informative
                  design promoting dental hygiene with visually compelling
                  elements for an engaging message.
                </span>
              </div>
              <span className='view-in-behance-81'>View In Behance</span>
              <div className='vector-82' />
            </div>
            <div className='content-83'>
              <div className='content-84'>
                <div className='title-85'>
                  <span className='poster-design'>Poster design</span>
                  <span className='nike-poster-design'>
                    Nike Poster Design in Photoshop: A visually impactful and
                    dynamic promotional poster capturing the essence of the Nike
                    brand.
                  </span>
                </div>
              </div>
              <div className='avatar-86'>
                <div className='content-87'>
                  <span className='view-in-behance-88'>View In Behance</span>
                  <div className='vector-89' />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='about-me-8a' />
      </div>
      <span className='certificates'>Certificates</span>
      <div className='flex-row-8b'>
        <div className='rectangle-8c'>
          <div className='screenshot' />
          <span className='front-end-developer'>Front-End Developer</span>
          <span className='meta-front-end-developer'>
            META/Front-End Developer Course on Coursera: Comprehensive training
            with 9 certificates, equipping you with the skills and credentials
            for mastery in front-end development.
          </span>
        </div>
        <div className='rectangle-8d'>
          <div className='screenshot-8e' />
          <span className='front-end-developer-8f'>Front-End Developer</span>
          <span className='meta-front-end-developer-batch'>
            META/Front-End Developer Batch Course on Coursera: Attain expertise
            with 9 certificates, accelerating your journey to becoming a
            proficient front-end developer.
          </span>
        </div>
      </div>
      <div className='flex-row-b-90'>
        <div className='rectangle-91'>
          <div className='screenshot-92' />
          <span className='design-and-develop-a-website'>
            Design and Develop a Website using Figma and CSS
          </span>
          <span className='project-network-design-and-develop-a-website'>
            "Project Network Design and Develop a Website using Figma and CSS
            Course on Coursera: Mastery demonstrated through 9 certificates in
            website development and design."
          </span>
        </div>
        <div className='rectangle-93'>
          <div className='empty' />
          <span className='flutter-development'>Flutter Development</span>
          <span className='getting-started-with-flutter-development'>
            "Getting Started with Flutter Development Course on Coursera: Obtain
            essential certificates, paving the way for expertise in
            cross-platform app development with Flutter."
          </span>
        </div>
      </div>
      <div className='flex-row-df'>
        <div className='rectangle-94'>
          <div className='screenshot-95' />
          <span className='learn-ui-design-fundamentals'>
            Learn UI Design Fundamentals
          </span>
          <span className='scrimbas-learn-ui-design-fundamentals'>
            Scrimba's Learn UI Design Fundamentals course on Coursera provides a
            comprehensive understanding of essential UI design principles and
            techniques.
          </span>
        </div>
        <div className='rectangle-96'>
          <div className='screenshot-97' />
          <span className='software-engineering'>Software Engineering</span>
          <span className='ibm-introduction-to-software-engineering'>
            The IBM Introduction to Software Engineering course on Coursera
            equips learners with foundational knowledge and skills in software
            engineering practices.
          </span>
        </div>
      </div>
      <div className='flex-row-d-98'>
        <div className='rectangle-99'>
          <span className='designing-ui-ux'>Designing UI & UX</span>
          <span className='ibm-designing-ui-ux'>
            The IBM Designing UI & UX course on Coursera offers a comprehensive
            exploration of user interface and user experience design principles,
            enhancing participants' design proficiency.
          </span>
        </div>
        <div className='designing-user-interfaces-and-experience' />
        <div className='rectangle-9a'>
          <div className='empty-9b' />
          <span className='principles-of-ux-ui-design'>
            Principles of UX / UI Design
          </span>
          <span className='meta-principles-of-ux-ui-design'>
            The Meta Principles of UX & UI Design course on Coursera provides a
            structured approach to mastering key principles for creating
            effective and user-centered digital experiences.
          </span>
        </div>
      </div>
      <div className='flex-row-f'>
        <div className='vector-9c'>
          <div className='group-9d' />
        </div>
        <div className='vector-9e'>
          <div className='flex-column-e'>
            <span className='hari-gmail-com'>hari64118@gmail.com</span>
            <span className='text-54'>91+ 93446 59136</span>
          </div>
          <div className='flex-column-aad'>
            <div className='vector-9f' />
            <div className='vector-a0' />
          </div>
        </div>
        <div className='ellipse-a1' />
        <div className='mask-group' />
        <div className='rectangle-a2'>
          <div className='vector-a3' />
          <div className='flex-row-f-a4'>
            <span className='skills'>Skills</span>
            <span className='about-me-a5'>About me </span>
            <span className='portfolio'>Portfolio</span>
            <span className='certificates-a6'>Certificates</span>
            <div className='vector-a7' />
          </div>
          <div className='flex-row-b-a8'>
            <span className='home'>Home</span>
            <div className='vector-a9' />
          </div>
          <div className='flex-row-edf'>
            <div className='vector-aa' />
            <div className='divider' />
          </div>
        </div>
        <span className='hariharan-v-ab'>HARIHARAN V</span>
        <span className='hariharan-v-ac'>Hariharan v</span>
      </div>
      <span className='graphic-ui-ux-designer'>Graphic & UI/uX Designer</span>
      <div className='flex-row-ab'>
        <span className='coimbatore'>Coimbatore</span>
        <div className='vector-ad'>
          <div className='vector-ae' />
        </div>
      </div>
      <div className='navbar'>
        <div className='mask-group-af' />
        <div className='container'>
          <div className='column' />
          <button className='button-b0'>
            <span className='contact-me'>Contact Me</span>
          </button>
          <div className='hari'>
            <span className='h'>H</span>
            <span className='ari'>ARI</span>
          </div>
          <div className='column-b1' />
          <div className='column-b2'>
            <span className='home-b3'>Home</span>
            <span className='skills-b4'>Skills</span>
            <span className='about-us'>About me</span>
            <span className='portfolio-b5'>Portfolio</span>
            <span className='certificates-b6'>Certificates</span>
          </div>
        </div>
      </div>
      <div className='flex-row-d-b7'>
        <div className='layer' />
        <div className='header'>
          <div className='flex-column'>
            <div className='group-b8' />
            <div className='star' />
            <div className='star-b9' />
            <div className='star-ba' />
          </div>
          <div className='flex-column-ec'>
            <div className='hey-i-am-hariharan-v'>
              <span className='hey-i-am-h'>Hey, I am H</span>
              <span className='ariharan-v'>ariharan v</span>
            </div>
            <div className='graphic-ui-ux-designer-and-brand-experience'>
              <span className='graphic-ui'>Graphic & </span>
              <span className='ux-designer'>UI/UX Designer </span>
              <span className='and-brand-experience'>and brand experience</span>
            </div>
            <span className='experienced-graphic-ui-ux-designer'>
              Experienced Graphic UI/UX Designer with a year of professional
              expertise. Specializing in creative design thinking, I focus on
              crafting compelling and user-centric UI/UX solutions. Passionate
              about delivering impactful design experiences.
            </span>
            <div className='background-cloud' />
            <div className='group-bb'>
              <div className='group-bc' />
            </div>
            <div className='button-bd'>
              <button className='get-in-touch' />
            </div>
            <div className='group-be' />
            <div className='imac'>
              <div className='group-bf'>
                <div className='dots' />
              </div>
              <div className='ui'>
                <div className='group-c0' />
              </div>
            </div>
            <div className='lamp' />
            <div className='plant' />
            <div className='pencil' />
            <div className='cat' />
            <div className='book' />
            <div className='seat' />
            <div className='layer-c1' />
            <div className='table-locker'>
              <div className='book-c2' />
            </div>
          </div>
          <div className='flex-column-c3'>
            <div className='star-c4' />
            <div className='star-c5' />
            <div className='star-c6' />
          </div>
          <div className='flex-column-c7'>
            <div className='star-c8' />
            <div className='star-c9' />
          </div>
          <div className='star-ca' />
          <div className='flex-column-d'>
            <div className='star-cb' />
            <div className='star-cc' />
            <div className='star-cd' />
          </div>
        </div>
      </div>
      <div className='rectangle-ce' />
    </div>
  );
}
